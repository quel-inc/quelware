
class AwgTimeoutError(Exception):
    pass

class CaptureUnitTimeoutError(Exception):
    pass