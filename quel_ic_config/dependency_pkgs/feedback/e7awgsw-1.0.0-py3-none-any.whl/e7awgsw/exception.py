
class AwgTimeoutError(Exception):
    pass

class CaptureUnitTimeoutError(Exception):
    pass

class TooLittleFreeSpaceInCmdFifoError(Exception):
    pass

class SequencerTimeoutError(Exception):
    pass
