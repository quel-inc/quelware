import logging
from typing import Collection, Dict, Final, List, Set, Union

from quel_ic_config import Quel1SeProtoExternalThermistor, Quel1SeProtoThermistor

from quel_cmod_scripting.quel_cmod_abstract import QuelCmodAbstract

logger = logging.getLogger(__name__)


class Quel1SeProtoCmod(QuelCmodAbstract):
    CORRESPONDING_VARIANTS: Set[str] = {"quel1seproto"}
    MINIMUM_VERSION: str = "0.0.3"
    NUM_X_HEATER: Final[int] = 14
    HEATER_PERIOD: Final[int] = 5000000  # 20Hz
    B_HEATER_MAP = {
        "adda": {
            "lmx2594": [0, 1],
            "pathsel": [2, 3],
        },
        "mx0": {
            "lmx2594": [2, 1, 7, 6],
            "adrf6780": [3, 0, 4, 5],
        },
        "mx1": {
            "lmx2594": [2, 1, 7, 6],
            "adrf6780": [3, 0, 4, 5],
        },
    }

    def __init__(self, host: str, port: int, mixerboard: Union[None, Collection[int]] = None, aux_mode: bool = False):
        super().__init__(host, port)
        if mixerboard is None:
            if aux_mode:
                mixerboard = set()
            else:
                mixerboard = {0, 1}
        self.available_mixer_board: Collection[int] = mixerboard
        self.num_x_thermistor = 0
        self.aux_mode = aux_mode

    def _checked_execute(self, cmd) -> str:
        reply = self.execute(cmd)
        if "error:" in reply:
            raise RuntimeError(reply)
        return reply

    def init(self):
        # adda
        self._checked_execute("spistart_adda!")
        self._checked_execute("spiselect_adda! 0")
        self._checked_execute("spicpolcpha_adda! 0 1")
        self._checked_execute("spicmd2_adda! 800c")

        # mixer0
        self._checked_execute("spistart_mx0!")
        self._checked_execute("spiselect_mx0! 0")
        self._checked_execute("spicpolcpha_mx0! 0 1")
        self._checked_execute("spicmd2_mx0! 800c")

        # mixer1
        self._checked_execute("spistart_mx1!")
        self._checked_execute("spiselect_mx1! 0")
        self._checked_execute("spicpolcpha_mx1! 0 1")
        self._checked_execute("spicmd2_mx1! 800c")

        # heater
        heater_period_actual = int(self._checked_execute("hdtest! 0 1"))
        if heater_period_actual != self.HEATER_PERIOD:
            logger.warning(f"be aware that heater_period is altered from {self.HEATER_PERIOD}")

    def init_heater(self):
        step = self.HEATER_PERIOD // self.NUM_X_HEATER
        for heater_id in range(self.NUM_X_HEATER):
            self._checked_execute(f"hdtest! {heater_id} 2 {step * heater_id}")
        self._checked_execute("hdstart!")

    def enable_x_thermistor(self, n: int):
        if 0 <= n <= 8:
            self.num_x_thermistor = n
        else:
            raise ValueError("invalid number of external thermistors (0 -- 8)")

    def _check_availability(self, target: str):
        if target == "adda":
            return True
        elif target == "mx0":
            return 0 in self.available_mixer_board
        elif target == "mx1":
            return 1 in self.available_mixer_board
        else:
            raise ValueError(f"invalid target: {target}")

    def neutral(self):
        self._checked_execute("hdstop!")
        self._checked_execute("fan_set! 128 128")

        for target in ("adda", "mx0", "mx1"):
            if not self._check_availability(target):
                continue
            self._checked_execute(f"spiselect_{target}! 0")
            self._checked_execute(f"spicpolcpha_{target}! 0 1")
            for i in range(8):
                self._checked_execute(f"spicmd2_{target}! {(i << 12):x}")
            self._checked_execute(f"spicmd2_{target}! a002")

        for heater_id in range(self.NUM_X_HEATER):
            self._checked_execute(f"hdtest! {heater_id} 3 0")

    def _write_ad5328(self, target: str, ch: int, val: int) -> None:
        if not self._check_availability(target):
            raise RuntimeError(f"target '{target}' is not available")

        if not 0 <= ch <= 7:
            raise ValueError(f"invalid channel of AD5328: {ch}")

        if not 0 <= val <= 4095:
            raise ValueError(f"invalid value for a channel of AD5328: {val}")

        self._checked_execute(f"spiselect_{target}! 0")
        self._checked_execute(f"spicpolcpha_{target}! 0 1")
        self._checked_execute(f"spicmd2_{target}! {((ch << 12) | val):x}")
        self._checked_execute(f"spicmd2_{target}! a002")

    def _read_ad7490(self, target: str, num_ch: int, double_range: bool = False) -> List[int]:
        if not self._check_availability(target):
            raise RuntimeError(f"target '{target}' is not available")

        self._checked_execute(f"spiselect_{target}! 1")
        self._checked_execute(f"spicpolcpha_{target}! 1 0")
        val: List[int] = []
        if double_range:
            self._checked_execute(f"spicmd2_{target}! ff90")
        else:
            self._checked_execute(f"spicmd2_{target}! ffb0")
        for i in range(num_ch):
            chv = int(self._checked_execute(f"spicmd2_{target}! 0").strip(), 16)
            ch = (chv >> 12) & 0xF
            if ch != i:
                raise RuntimeError(f"unexpected data: '{chv:x}' is read at {i}-th reading")
            v = chv & 0xFFF
            val.append(v)
        return val

    def read_adda_ad7490(self) -> Dict[str, List[int]]:
        r: Dict[str, List[int]] = {}

        if self.aux_mode:
            if self.num_x_thermistor > 0:
                s = self._read_ad7490("adda", 2 + self.num_x_thermistor, True)
                r["x"] = s[2:]
        else:
            t = self._read_ad7490("adda", 2 + min(self.num_x_thermistor, 2))
            r["lmx2594"] = t[0:2]
            if self.num_x_thermistor > 0:
                r["pathsel"] = t[2:]
            if self.num_x_thermistor > 2:
                s = self._read_ad7490("adda", 2 + self.num_x_thermistor, True)
                r["x"] = s[4:]
            # TODO: supporting add-on thermistors and name them if necessary.
        return r

    def read_mx0_ad7490(self) -> Dict[str, List[int]]:
        t = self._read_ad7490("mx0", 8)
        return {
            "lmx2594": [t[0], t[3], t[7], t[6]],
            "adrf6780": [t[1], t[2], t[4], t[5]],
        }

    def read_mx1_ad7490(self) -> Dict[str, List[int]]:
        t = self._read_ad7490("mx1", 8)
        return {
            "lmx2594": [t[0], t[3], t[7], t[6]],
            "adrf6780": [t[1], t[2], t[4], t[5]],
        }

    def read_temp(self, enable_adda=True, enable_mx0=True, enable_mx1=True):
        th = Quel1SeProtoThermistor("any")
        thx = Quel1SeProtoExternalThermistor("any")

        t: Dict[str, List[float]] = {}
        if enable_adda and self._check_availability("adda"):
            for k, v in self.read_adda_ad7490().items():
                try:
                    if k == "lmx2594":
                        t1 = [int(th.convert(v1) * 1000 + 0.5) / 1000.0 for v1 in v]
                    elif k == "pathsel":
                        t1 = [int(th.convert(v1) * 1000 + 0.5) / 1000.0 for v1 in v]
                    elif k == "x":
                        t1 = [int(thx.convert(v1) * 1000 + 0.5) / 1000.0 for v1 in v]
                    else:
                        raise AssertionError
                except ValueError:
                    raise RuntimeError("broken data for {i}-th reading: 0x{v:x}")
                t["adda_" + k] = t1
        if enable_mx0 and self._check_availability("mx0"):
            for k, v in self.read_mx0_ad7490().items():
                try:
                    t1 = [int(th.convert(v1) * 1000 + 0.5) / 1000.0 for v1 in v]
                except ValueError:
                    raise RuntimeError("broken data for {i}-th reading: 0x{v:x}")
                t["mx0_" + k] = t1
        if enable_mx1 and self._check_availability("mx1"):
            for k, v in self.read_mx1_ad7490().items():
                try:
                    t1 = [int(th.convert(v1) * 1000 + 0.5) / 1000.0 for v1 in v]
                except ValueError:
                    raise RuntimeError("broken data for {i}-th reading: 0x{v:x}")
                t["mx1_" + k] = t1
        return t

    def _read_current(self, target: str) -> List[float]:
        if not self._check_availability(target):
            raise RuntimeError(f"target '{target}' is not available")

        self._checked_execute(f"spicpolcpha_{target}! 0 1")
        current: List[float] = []
        for i in range(6):
            self._checked_execute(f"spiselect_{target}! {i+2}")
            v = self._checked_execute(f"spicmd3_{target}! 1d0000")
            r = int(v.strip(), 16)
            if i in {0, 1, 2, 3}:
                current.append(r * 0.05)
            elif i == 4:
                current.append(r * 0.05 * 2)
            elif i == 5:
                current.append(r * 0.05 * 12.5)
            else:
                raise AssertionError
        return current

    def read_mx0_current(self) -> Dict[str, List[float]]:
        c = self._read_current("mx0")
        return {
            "lmx2594": c[0:4],
            "6V": c[4:5],
            "4V": c[5:6],
        }

    def read_mx1_current(self) -> Dict[str, List[float]]:
        c = self._read_current("mx1")
        return {
            "lmx2594": c[0:4],
            "6V": c[4:5],
            "4V": c[5:6],
        }

    def read_current(self, enable_mx0=True, enable_mx1=True):
        t: Dict[str, List[float]] = {}
        if enable_mx0 and self._check_availability("mx0"):
            for k, v in self.read_mx0_current().items():
                t["mx0_" + k] = v
        if enable_mx1 and self._check_availability("mx1"):
            for k, v in self.read_mx1_current().items():
                t["mx1_" + k] = v
        return t

    def _set_adrf6780_pwdn(self, target: str, pwdn: bool) -> None:
        if not self._check_availability(target):
            raise RuntimeError(f"target {target} is not available")

        if pwdn:
            self._checked_execute(f"gpio_{target}_set! 3")
        else:
            self._checked_execute(f"gpio_{target}_set! 1")

    def set_adrf6780_mx0_pwdn(self, pwdn: bool) -> None:
        self._set_adrf6780_pwdn("mx0", pwdn)

    def set_adrf6780_mx1_pwdn(self, pwdn: bool) -> None:
        self._set_adrf6780_pwdn("mx1", pwdn)

    def set_fan(self, ratio: float):
        if 0.0 <= ratio <= 1.0:
            self._checked_execute(f"fan_set! {int(ratio*255+0.5)}  {int(ratio*255+0.5)}")
        else:
            raise ValueError(f"invalid fan ratio: {ratio}")

    def set_b_heater(self, heater_id: str, ratio: float) -> None:
        """set the voltage of on-'b'ard heater.
        :param heater_id: a triplet of a board (either of "adda", "mx0" or "mx1"), a type of the corresponding ic
        (either "lmx2594" or "adrf6780", depending on the board), and an index of the corresponding ic.
        :param ratio: 0.0 -- 0.7 (0W to approximately 0.5W, the power is nearly proportional to the square
        of the ratio.)
        :return: None
        """
        board, ic_kind, idx_s = tuple(heater_id.split(":"))
        idx = int(idx_s)

        if not self._check_availability(board):
            raise RuntimeError(f"board '{board}' is not available")
        if ic_kind not in self.B_HEATER_MAP[board]:
            raise ValueError(f"invalid ic for board {board}:'{ic_kind}'")
        if not (0 <= idx < len(self.B_HEATER_MAP[board][ic_kind])):
            raise ValueError(f"invalid index of the board {board}:{ic_kind}:'{idx}'")
        if not (0.0 <= ratio <= 0.7):
            raise ValueError(f"invalid heater ratio: {ratio}")

        ch = self.B_HEATER_MAP[board][ic_kind][idx]
        self._write_ad5328(board, ch, int(ratio * 4095 + 0.5))

    def set_x_heater(self, heater_id: str, ratio: float):
        board, idx_s = tuple(heater_id.split(":"))
        if not self._check_availability(board):
            raise RuntimeError(f"board '{board}' is not available")

        idx = int(idx_s)
        if board == "adda" and (0 <= idx < 6):
            idx += 0
        elif board == "mx0" and (0 <= idx < 4):
            idx += 6
        elif board == "mx1" and (0 <= idx < 4):
            idx += 10
        else:
            raise ValueError(f"invalid heater_id: {heater_id}")

        if not (0 <= idx < self.NUM_X_HEATER):
            raise ValueError(f"invalid heater index: {idx}")
        if not (0.0 <= ratio <= 1.0):
            raise ValueError(f"invalid heater ratio: {ratio}")
        self._checked_execute(f"hdtest! {idx} 3 {int(ratio * self.HEATER_PERIOD)}")
